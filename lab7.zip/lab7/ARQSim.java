import java.util.*;

public class ARQSim {
    static Random random = new Random();
    static Scanner sc = new Scanner(System.in);

    static boolean sendFrame(int frameNumber) {
        boolean lost = random.nextInt(100) < 20; 
        if (lost) {
            System.out.println("Frame " + frameNumber + " lost during transmission.");
            return false;
        } else {
            System.out.println("Frame " + frameNumber + " received successfully.");
            return true;
        }
    }

    static boolean receiveAck(int frameNumber) {
        boolean ackLost = random.nextInt(100) < 10; 
        if (ackLost) {
            System.out.println("ACK for Frame " + frameNumber + " lost.");
            return false;
        } else {
            System.out.println("ACK for Frame " + frameNumber + " received.");
            return true;
        }
    }

    static void stopAndWait(int totalFrames) {
        for (int i = 1; i <= totalFrames; i++) {
            boolean acked = false;
            while (!acked) {
                System.out.println("\nSending Frame " + i + "...");
                boolean sent = sendFrame(i);
                if (sent) {
                    acked = receiveAck(i);
                }
                if (!acked) {
                    System.out.println("Resending Frame " + i + " due to lost frame or ACK...");
                }
            }
        }
        System.out.println("\nAll frames sent and acknowledged successfully with Stop-and-Wait!");
    }

    static void goBackN(int totalFrames, int windowSize) {
        int base = 1;
        int nextFrame = 1;

        while (base <= totalFrames) {
            // Send frames within window
            while (nextFrame < base + windowSize && nextFrame <= totalFrames) {
                System.out.println("\nSending Frame " + nextFrame + "...");
                sendFrame(nextFrame);  // whether received or not
                nextFrame++;
            }

            // Wait for cumulative ACK
            int ackFrame = base;
            boolean ackReceived = receiveAck(ackFrame);
            if (ackReceived) {
                base++; // Slide window forward
            } else {
                System.out.println("Timeout! Resending frames from Frame " + base);
                nextFrame = base; // Go back and resend from base
            }
        }

        System.out.println("\nAll frames sent and acknowledged successfully with Go-Back-N!");
    }

    static void selectiveRepeat(int totalFrames, int windowSize) {
        boolean[] acked = new boolean[totalFrames + 1];
        int base = 1;
        int nextFrame = 1;

        while (base <= totalFrames) {
            // Send frames within window
            while (nextFrame < base + windowSize && nextFrame <= totalFrames) {
                System.out.println("\nSending Frame " + nextFrame + "...");
                boolean received = sendFrame(nextFrame);
                if (received) {
                    acked[nextFrame] = receiveAck(nextFrame);
                }
                nextFrame++;
            }

            // Resend unacknowledged frames
            for (int i = base; i < base + windowSize && i <= totalFrames; i++) {
                if (!acked[i]) {
                    System.out.println("Resending Frame " + i + " due to missing ACK...");
                    boolean received = sendFrame(i);
                    if (received) {
                        acked[i] = receiveAck(i);
                    }
                }
            }

            // Slide window forward
            while (base <= totalFrames && acked[base]) base++;           
        }

        System.out.println("\nAll frames sent and acknowledged successfully with Selective Repeat!");
    }

    public static void main(String[] args) {
        System.out.println("ARQ Protocol Simulation");
        System.out.println("1. Stop-and-Wait ARQ");
        System.out.println("2. Go-Back-N ARQ");
        System.out.println("3. Selective Repeat ARQ");
        System.out.print("Choose protocol (1-3): ");
        int choice = sc.nextInt();

        System.out.print("Enter number of frames to send: ");
        int totalFrames = sc.nextInt();

        int windowSize = 1;
        if (choice == 2 || choice == 3) {
            System.out.print("Enter window size: ");
            windowSize = sc.nextInt();
        }

        switch (choice) {
            case 1 : 
            	stopAndWait(totalFrames);
            	break;
            	
            case 2 : 
            	goBackN(totalFrames, windowSize);
            	break;
            	
            case 3 : 
            	selectiveRepeat(totalFrames, windowSize);
            	break;
            	
            default : 
            	System.out.println("Invalid choice!");
        }
    }
}
