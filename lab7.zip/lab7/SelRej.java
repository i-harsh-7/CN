import java.util.Random;
import java.util.Scanner;

class SelectiveRepeatARQ {
    static Random random = new Random();

    // Simulate sending a frame
    static boolean sendFrame(int frameNumber) {
        boolean lost = random.nextInt(100) < 20; // 20% chance frame lost
        if (lost) {
            System.out.println("Frame " + frameNumber + " lost during transmission.");
            return false;
        } else {
            System.out.println("Frame " + frameNumber + " received successfully.");
            return true;
        }
    }

    // Simulate sending ACK
    static boolean sendAck(int frameNumber) {
        boolean ackLost = random.nextInt(100) < 10; // 10% chance ACK lost
        if (ackLost) {
            System.out.println("ACK for Frame " + frameNumber + " lost.");
            return false;
        } else {
            System.out.println("ACK for Frame " + frameNumber + " received.");
            return true;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of frames to send: ");
        int totalFrames = sc.nextInt();
        System.out.print("Enter window size: ");
        int windowSize = sc.nextInt();

        boolean[] acked = new boolean[totalFrames + 1];
        int base = 1;
        int nextFrame = 1;

        while (base <= totalFrames) {
            // Send frames within window
            while (nextFrame < base + windowSize && nextFrame <= totalFrames) {
                System.out.println("\nSending Frame " + nextFrame + "...");
                boolean received = sendFrame(nextFrame);

                if (received) {
                    acked[nextFrame] = sendAck(nextFrame);
                }
                nextFrame++;
            }

            // Check for unacknowledged frames and resend only them
            for (int i = base; i < base + windowSize && i <= totalFrames; i++) {
                if (!acked[i]) {
                    System.out.println("Resending Frame " + i + " due to missing ACK...");
                    boolean received = sendFrame(i);
                    if (received) {
                        acked[i] = sendAck(i);
                    }
                }
            }

            // Slide window forward
            while (base <= totalFrames && acked[base]) {
                base++;
            }
        }

        System.out.println("\nAll frames sent and acknowledged successfully!");
        sc.close();
    }
}
