import java.util.Random;
import java.util.Scanner;

class GoBack {
    static Random random = new Random();

    // Simulate sending a frame (true if received successfully)
    static boolean sendFrame(int frameNumber) {
        boolean lost = random.nextInt(100) < 20; // 20% chance frame lost
        if (lost) {
            System.out.println("Frame " + frameNumber + " lost during transmission.");
            return false;
        } else {
            System.out.println("Frame " + frameNumber + " received successfully.");
            return true;
        }
    }

    // Simulate sending ACK (cumulative)
    static boolean sendAck(int frameNumber) {
        boolean ackLost = random.nextInt(100) < 10; // 10% chance ACK lost
        if (ackLost) {
            System.out.println("ACK for Frame " + frameNumber + " lost.");
            return false;
        } else {
            System.out.println("ACK for Frame " + frameNumber + " received.");
            return true;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of frames to send: ");
        int totalFrames = sc.nextInt();
        System.out.print("Enter window size: ");
        int windowSize = sc.nextInt();

        int base = 1;
        int nextFrame = 1;

        while (base <= totalFrames) {
            // Send frames within window
            while (nextFrame < base + windowSize && nextFrame <= totalFrames) {
                System.out.println("\nSending Frame " + nextFrame + "...");
                sendFrame(nextFrame);  // Whether received or not, sender moves window
                nextFrame++;
            }

            // Wait for ACK (simulate cumulative ACK)
            int ackFrame = base;
            boolean ackReceived = sendAck(ackFrame);

            if (ackReceived) {
                base++;  // Slide window forward
            } else {
                System.out.println("Timeout! Resending frames from Frame " + base);
                nextFrame = base;  // Go back and resend from base
            }
        }

        System.out.println("\nAll frames sent and acknowledged successfully!");
        sc.close();
    }
}
