import java.util.Random;
import java.util.Scanner;

class StopWait {

    static Random random = new Random();

    // Simulate sending a frame (returns true if successfully received)
    static boolean sendFrame(int frameNumber) {
        // 20% chance that the frame is lost
        boolean lost = random.nextInt(100) < 20;
        if (lost) {
            System.out.println("Frame " + frameNumber + " lost during transmission.");
            return false;
        } else {
            System.out.println("Frame " + frameNumber + " successfully received.");
            return true;
        }
    }

    // Simulate receiving an acknowledgment (returns true if ACK received)
    static boolean receiveAck(int frameNumber) {
        // 10% chance that ACK is lost
        boolean ackLost = random.nextInt(100) < 10;
        if (ackLost) {
            System.out.println("ACK for Frame " + frameNumber + " lost.");
            return false;
        } else {
            System.out.println("ACK for Frame " + frameNumber + " received.");
            return true;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of frames to send: ");
        int numFrames = sc.nextInt();

        for (int i = 1; i <= numFrames; i++) {
            boolean frameAcked = false;

            while (!frameAcked) {
                System.out.println("\nSending Frame " + i + "...");
                boolean sent = sendFrame(i);

                if (sent) {
                    // Wait for ACK
                    frameAcked = receiveAck(i);
                }

                if (!frameAcked) {
                    System.out.println("Resending Frame " + i + " due to lost frame or ACK...");
                }
            }
        }

        System.out.println("\nAll frames sent and acknowledged successfully!");
        sc.close();
    }
}
