import java.util.Scanner;

public class Hamming2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Input the binary string
        System.out.print("Enter binary string: ");
        String s = sc.nextLine();
        
        int n = s.length();
        int r = 1;
        
        // Calculate the number of redundant (parity) bits required
        while ((1 << r) < n + r + 1) {
            r++;
        }
        
        // Create the result string initialized with '*' characters
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < n + r; i++) {
            res.append('*');
        }

        int idx = 0;
        // Place the data bits in the right positions
        for (int i = 0; i < n + r; i++) {
            if ((i & (i + 1)) != 0) {
                res.setCharAt(n + r - 1 - i, s.charAt(n - (idx++) - 1));
            }
        }
        
        System.out.println("Intermediate: " + res);
        
        // Calculate and set the parity bits
        for (int i = 0; i < r; i++) {
            int par = 0;
            for (int j = 0; j < n + r; j++) {
                if (((j + 1) & (1 << i)) != 0) {
                    if (res.charAt(n + r - 1 - j) == '1') {
                        par++;
                    }
                }
            }
            if (par % 2 != 0) {
                res.setCharAt(n + r - (1 << i), '1');
            } else {
                res.setCharAt(n + r - (1 << i), '0');
            }
        }

        System.out.println("Encoded String: " + res);
        
        // Introducing a single bit error
        int bit = 2; // Example bit index to flip (from the received data)
        System.out.println(bit + " bit is flipped");
        char flippedBit = (res.charAt(n + r - bit) == '1') ? '0' : '1';
        res.setCharAt(n + r - bit, flippedBit);
        
        System.out.println("Received Data: " + res);
        
        // Error detection and correction
        int error = 0;
        for (int i = 0; i < r; i++) {
            int par = 0;
            for (int j = 0; j < n + r; j++) {
                if (((j + 1) & (1 << i)) != 0) {
                    if (res.charAt(n + r - 1 - j) == '1') {
                        par++;
                    }
                }
            }
            if (par % 2 != 0) {
                error += (1 << i);
            }
        }
        
        if (error != 0) {
            System.out.println("Error bit: " + error);
            char correctedBit = (res.charAt(n + r - error) == '1') ? '0' : '1';
            res.setCharAt(n + r - error, correctedBit);
            System.out.println("Corrected Data: " + res);
        } else {
            System.out.println("No Error");
        }

        sc.close();
    }
}
