import java.util.*;

public class Hamming{

	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("--- Hamming Code ---");
		
		System.out.print("Enter the binary string (Sender side) : ");
		String s1 = sc.next();
		String hamStr1 = hamming(s1);
		
		System.out.println("After encoding : " + hamStr1);
		
		System.out.print("Enter the binary string (Receiver side) : ");
		String s2 = sc.next();
		String hamStr2 = hamming(s2);
	
	}
	
	static String hamming(String s){
		int l = s.length();
		int r = calc(l, 1);
		
		int len = l+r;
		char arr[] = new char[len];
		Arrays.fill(arr, '*');
		
		char input[] = s.toCharArray();
		
		int j =0;
		
		for(int i=0; i<len; i++){
			int k = len - i;
			if(k!=0 && ((k&(k-1)) != 0)){
				arr[i] = input[j++];
			}
		}
		System.out.println(Arrays.toString(arr));
		
		for (int i = len - 1; i >= 0; i--) {
    
    			if (arr[i] == '*') {
        			int k = len - i; 
        			int cnt = 0, check = 1;
        			boolean flag = true;
        
        			for (int ind = k - 2; ind >= 0; ind--) {
            				if (flag) {
                				if (arr[ind] == '1') cnt++;
                				check++;
               				if (check >= k) flag = false;
            				} 
            				else {
                				check--;
                				if (check == 0) flag = true;
            				}
        			}
        		if (cnt % 2 == 0) arr[i] = '0';
           		else	arr[i] = '1';  
        		
    		}
	}
		
		StringBuilder str = new StringBuilder("");
		for(char ch : arr){
			str.append(ch);
		}
		return str.toString();
	}
	
	static int calc(int d, int r){
		if(Math.pow(2, r) >= (d+r+1)) return r;
		return calc(d, r+1);
	}


}
