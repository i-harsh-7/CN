import java.util.*;


public class ErrorDet{

	static Scanner sc = new Scanner(System.in);

	public static void main(String abcd[]){
	
		System.out.print("Enter Binary Data: ");
        	String data = sc.nextLine();
        	
		System.out.println("Choose the method : \n1. Checksum (Sender) \n2. Checksum (Receiver) \n3. CRC (Sender) \n4. CRC (Receiver)");
		int ch = 0;
		
		String encoded = "";
		
		do{
			System.out.println("\nEnter your choice : ");
			ch = sc.nextInt();
			
			switch(ch){
				case 1: 
					checksumCalc(data);
					break;
					
				case 2 : 
					crcCalc(data);
					break;
				
				default : 
					System.out.println("Enter the right choice ...");
					break;
		
			}
		}while(ch>0 && ch<3);
	}
	
	public static void checksumCalc(String data){
		System.out.println("\n----- CHECKSUM -----");
		System.out.print("\nEnter the size of the segment : ");
		int k = sc.nextInt();
					
		String encode = checksum(data, k);
		String senderSide = data + encode;
		
        	System.out.println("Original Data : " + data);
		System.out.println("Checksum : " + encode);
        	System.out.println("Sender End Data : " + senderSide);
        	
        	//receiver side
        	System.out.print("Enter the data at reciver side : ");
        	String receiverSide = sc.next();
        	String verifySum = checksum(receiverSide, k);

        	System.out.println("Receiver Verification: " + verifySum);

        	if (verifySum.matches("0+"))
            		System.out.println("No Error Detected (Checksum)");
        	else
            		System.out.println("Error Detected (Checksum)");
	}
	
	static String addBinary(String a, String b) {
        	int maxLen = Math.max(a.length(), b.length());

        	a = String.format("%" + maxLen + "s", a).replace(' ', '0');
        	b = String.format("%" + maxLen + "s", b).replace(' ', '0');

        	String result = "";
       	 int carry = 0;

       	for (int i = maxLen - 1; i >= 0; i--) {
            		int sum = (a.charAt(i) - '0') + (b.charAt(i) - '0') + carry;
            		result = (sum % 2) + result;
            		carry = sum / 2;
        	}

        	if (carry == 1) {
            		result = addBinary(result, "1");
        	}

        	return result;
    	}

    	static String onesComplement(String bin) {
        	String result = "";

        	for (char c : bin.toCharArray()) {
            		result += (c == '0') ? "1" : "0";
        	}

        	return result;
    	}

    	static String checksum(String data, int size) {
        	int length = data.length();

        	if (length % size != 0) {
            		int pad = size - (length % size);
            		data = "0".repeat(pad) + data;
        	}

        	String sum = data.substring(0, size);

        	for (int i = size; i < data.length(); i += size) {
            		String segment = data.substring(i, i + size);
            		sum = addBinary(sum, segment);
        	}

        	return onesComplement(sum);
    	}
    	
    	static String xor(String a, String b) {
        	String result = "";

        	for (int i = 1; i < b.length(); i++) {
            		result += (a.charAt(i) == b.charAt(i)) ? "0" : "1";
        	}

        	return result;
    	}
    
    	static void crcCalc(String data){
    		System.out.println("\n----- CRC -----");
    		System.out.println("\nEnter the divisor : ");
    		String divisor = sc.next();
    	
        	String crc = generateCRC(data, divisor);
        	String senderData = data + crc;

        	System.out.println("Original Data   : " + data);
        	System.out.println("Generator       : " + divisor);

        	System.out.println("CRC Remainder   : " + crc);
        	System.out.println("Sender End Data : " + senderData);


		System.out.print("Enter the data at receiver's End : ");
		String receiverData = sc.next();
        	String recRem = crcDiv(receiverData, divisor);

        	System.out.println("Receiver Remainder: " + recRem);

        	if (recRem.equals("000"))
            		System.out.println("No Error Detected (CRC)");
        	else
            		System.out.println("Error Detected (CRC)");
    	}

    	static String crcDiv(String dividend, String divisor) {
        	int pick = divisor.length();

        	String tmp = dividend.substring(0, pick);
        	while (pick < dividend.length()) {
            		if (tmp.charAt(0) == '1')
                		tmp = xor(divisor, tmp) + dividend.charAt(pick);
            		else
                		tmp = xor("0".repeat(pick), tmp) + dividend.charAt(pick);

            		pick++;
        	}
	
        	if (tmp.charAt(0) == '1')
            		tmp = xor(divisor, tmp);
        	else
            		tmp = xor("0".repeat(pick), tmp);
        	
        	return tmp;
    	}

    	static String generateCRC(String data, String divisor) {
        	String appendedData = data + "0".repeat(divisor.length() - 1);
        	String remainder = crcDiv(appendedData, divisor);

        	return remainder;
    	}
	
}








