import java.util.*;

public class Shannon{
	public static void main(String abcd[]){
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the BandWidth capacity : ");
		double b = sc.nextFloat();
		
		System.out.print("Enter the SNR value : 1. in hertz \n 2. in dB \n");
		int ch = sc.nextInt();
		System.out.print("Enter the value : ");
		double snr = sc.nextFloat();
		
		if(ch==2){
			double power = snr/10; 
			snr = Math.pow(10, power);
		}
		
		double cap = b*log2(1+snr);
		
		System.out.println("Capacity = " + cap);
	
	}
	
	public static double log2(double n) {
    		return Math.log10(n) / Math.log10(2);
	}

}
