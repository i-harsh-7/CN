import java.util.*;

public class LoadShed{

	static Scanner sc = new Scanner(System.in);
	static Random ran = new Random();
	
	static class Packet{
		int pNo, priority;
		String appl;
		
		Packet(int pNo){
			this.pNo = pNo;
			priority = -1;
			appl = "";
		}
		
		Packet(int pNo, int priority){
			this.pNo = pNo;
			this.priority = priority;
			appl = "";
		}
		
		Packet(int pNo, String appl){
			this.pNo = pNo;
			priority = -1;
			this.appl = appl;
		}
		
		@Override
		public String toString(){
			return String.format("PacketNumber %d , priority : %d, application : %s", pNo, priority, appl);
		}
	}
	
	public static void main(String[] args){
		System.out.println("Load Shedding methods ");
		System.out.print("Enter the buffer size : ");
		int s = sc.nextInt();
		
		System.out.println("1. Random Selcetion of Packets \n2. Application Based Selection \n3. Priority Based Selection \n4. Random Early Detection");
		
		System.out.print("Enter your choice : ");
		int ch = sc.nextInt();
		
		switch(ch){
			case 1:
				random(s);
				break;
				
			case 2:
				application(s);
				break;
				
			case 3:
				priority(s);
				break;
				
			case 4:
				randomEarly(s);
				break;
				
			default: 
				System.out.println("Enter the right choice ...");
				break;
				
		}
	
	}
	
	public static void random(int s){
		ArrayList<Packet> buffer = new ArrayList<>();
		
		System.out.println("Enter the packets detail in buffer : (packetNumber)");
		for(int i=0; i<s; i++){
			int pn = sc.nextInt();
			buffer.add(new Packet(pn));
		}
		
		System.out.println("Packets in Buffer : ");
		
		for(int i=0; i<s; i++){
			Packet p = buffer.get(i);
			System.out.print(p.pNo + " ");
		}
		System.out.println();
		
		while(s > 0){
			int ind = ran.nextInt(s);
			
			Packet p = buffer.get(ind);
			System.out.println(p.toString());
			
			buffer.remove(p);
			
			s--;
		}
	}
	
	public static void application(int s){
	
	
	}
	
	public static void priority(int s){
		ArrayList<Packet> buffer = new ArrayList<>();
		
		System.out.println("Enter the packets detail in buffer : (packetNumber, priority)");
		for(int i=0; i<s; i++){
			int pn = sc.nextInt();
			int pr = sc.nextInt();
			buffer.add(new Packet(pn, pr));
		}
		
		System.out.println("Packets in Buffer : ");
		for(int i=0; i<s; i++){
			Packet p = buffer.get(i);
			System.out.print(p.pNo + " ");
		}
		System.out.println();
		
		Collections.sort(buffer , Comparator.comparingInt(p -> p.priority));
		
		while(s > 0){
			Packet p = buffer.get(0);
			System.out.println(p.toString());
			
			buffer.remove(p);
			s--;
		}
	}
	
	public static void randomEarly(int s){
		int avg = s - s/5;
		
		System.out.println("Enter the packets detail in buffer : (packetNumber, priority)");
		for(int i=0; i<avg; i++){
			int pn = sc.nextInt();
			int pr = sc.nextInt();
			buffer.add(new Packet(pn, pr));
		}
		
	
	}

}





