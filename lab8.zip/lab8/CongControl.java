class CongControl {

    // 🔹 Leaky Bucket Class
    static class LeakyBucket {
        private int capacity, leakRate, currentWater;

        public LeakyBucket(int capacity, int leakRate) {
            this.capacity = capacity;
            this.leakRate = leakRate;
            this.currentWater = 0;
        }

        public void addPacket(int packets) {
            if (currentWater + packets > capacity) {
                System.out.println("Overflow! Dropped: " 
                        + (currentWater + packets - capacity));
                currentWater = capacity;
            } else {
                currentWater += packets;
            }
            System.out.println("Current level: " + currentWater);
        }

        public void leak() {
            int leaked = Math.min(currentWater, leakRate);
            currentWater -= leaked;
            System.out.println("Leaked: " + leaked 
                    + ", Remaining: " + currentWater);
        }
    }

    // 🔹 Token Bucket Class
    static class TokenBucket {
        private int capacity, tokens, refillRate;

        public TokenBucket(int capacity, int refillRate) {
            this.capacity = capacity;
            this.refillRate = refillRate;
            this.tokens = capacity; // initially full
        }

        public void refill() {
            tokens = Math.min(capacity, tokens + refillRate);
            System.out.println("Tokens after refill: " + tokens);
        }

        public void sendPacket(int packets) {
            if (tokens >= packets) {
                tokens -= packets;
                System.out.println("Sent " + packets 
                        + " packets. Remaining tokens: " + tokens);
            } else {
                System.out.println("Not enough tokens. Dropped: " 
                        + (packets - tokens));
                tokens = 0;
            }
        }
    }

    // 🔹 Main Method
    public static void main(String[] args) {

        System.out.println("=== Leaky Bucket Simulation ===");
        LeakyBucket lb = new LeakyBucket(10, 3);

        lb.addPacket(5);
        lb.leak();

        lb.addPacket(7);
        lb.leak();

        lb.addPacket(6);
        lb.leak();


        System.out.println("\n=== Token Bucket Simulation ===");
        TokenBucket tb = new TokenBucket(10, 4);

        tb.sendPacket(6);
        tb.refill();

        tb.sendPacket(8);
        tb.refill();

        tb.sendPacket(5);
    }
}
