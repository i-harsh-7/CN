import java.util.*;

public class LoadShed2 {

    static void RSP(int n, int bufferSize, Scanner sc) {
        List<Integer> data = new ArrayList<>();
        System.out.println("Enter packets: ");
        for (int i = 0; i < n; i++) {
            data.add(sc.nextInt());
        }
        int buffer = 0;
        for (int el : data) buffer += el;

        Random rand = new Random();

        while (buffer > bufferSize) {
            int i = rand.nextInt(data.size());
            System.out.println(data);
            System.out.println("Dropping packet " + (i + 1));
            buffer -= data.get(i);
            data.remove(i);
        }

        System.out.println("Remaining packets: " + data);
        System.out.println("Buffer: " + buffer);
    }

    static void ABS(int n, int bufferSize, Scanner sc) {
        List<Pair<String, Integer>> data = new ArrayList<>();
        System.out.println("Enter packets (APP & size): ");
        for (int i = 0; i < n; i++) {
            String app = sc.next();
            int size = sc.nextInt();
            data.add(new Pair<>(app, size));
        }

        int buffer = data.stream().mapToInt(p -> p.second).sum();
        Random rand = new Random();

        while (buffer > bufferSize) {
            int i = -1;
            for (int j = 0; j < data.size(); j++) {
                if (data.get(j).first.equals("FTP")) i = j;
            }
            if (i == -1) i = rand.nextInt(data.size());
            for (Pair<String, Integer> el : data) System.out.println(el);
            System.out.println("Dropping packet " + (i + 1));
            buffer -= data.get(i).second;
            data.remove(i);
        }

        System.out.println("Remaining packets: " + data);
        System.out.println("Buffer: " + buffer);
    }

    static void PBS(int n, int bufferSize, Scanner sc) {
        List<Pair<Integer, Integer>> data = new ArrayList<>();
        System.out.println("Enter packets (priority & size): ");
        for (int i = 0; i < n; i++) {
            int priority = sc.nextInt();
            int size = sc.nextInt();
            data.add(new Pair<>(priority, size));
        }

        int buffer = data.stream().mapToInt(p -> p.second).sum();

        while (buffer > bufferSize) {
            int i = -1, lowest = Integer.MAX_VALUE;
            for (int j = 0; j < data.size(); j++) {
                if (data.get(j).first < lowest) {
                    lowest = data.get(j).first;
                    i = j;
                }
            }
            for (Pair<Integer, Integer> el : data) System.out.println(el);
            System.out.println("Dropping packet " + (i + 1));
            buffer -= data.get(i).second;
            data.remove(i);
        }

        System.out.println("Remaining packets: " + data);
        System.out.println("Buffer: " + buffer);
    }

    static void RES(int n, int bufferSize, Scanner sc) {
        List<Integer> data = new ArrayList<>();
        List<Integer> temp = new ArrayList<>();
        System.out.println("Enter packets: ");
        for (int i = 0; i < n; i++) data.add(sc.nextInt());

        System.out.print("Enter threshold (less than buffer size): ");
        int threshold = sc.nextInt();

        int buffer = 0;
        Random rand = new Random();

        for (int i = 0; i < n; i++) {
            buffer += data.get(i);
            temp.add(data.get(i));
            while (buffer > threshold) {
                int idx = rand.nextInt(temp.size());
                System.out.println(temp);
                System.out.println("Dropping packet " + (idx + 1));
                buffer -= temp.get(idx);
                temp.remove(idx);
            }
        }

        System.out.println("Remaining packets: " + temp);
        System.out.println("Buffer: " + buffer);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter no. of packets: ");
        int n = sc.nextInt();
        System.out.print("Enter buffer size: ");
        int bufferSize = sc.nextInt();

        System.out.println("Choose one: ");
        System.out.println("1. Random Selection of Packets.");
        System.out.println("2. Application Based Selection.");
        System.out.println("3. Priority Based Selection.");
        System.out.println("4. Random Early Selection.");
        int ch = sc.nextInt();

        switch (ch) {
            case 1 :
            	RSP(n, bufferSize, sc);
            	break;
            	
            case 2 :
            	ABS(n, bufferSize, sc);
            	break;
            	
            case 3 :
            	PBS(n, bufferSize, sc);
            	break;
            	
            case 4 :
            	RES(n, bufferSize, sc);
            	break;
            	
            default :
            	System.out.println("Invalid!");
        }
 
    }

    // Simple Pair class since Java doesn't have built-in pairs
    static class Pair<F, S> {
        F first;
        S second;

        Pair(F first, S second) {
            this.first = first;
            this.second = second;
        }

        @Override
        public String toString() {
            return "(" + first + ", " + second + ")";
        }
    }
}
